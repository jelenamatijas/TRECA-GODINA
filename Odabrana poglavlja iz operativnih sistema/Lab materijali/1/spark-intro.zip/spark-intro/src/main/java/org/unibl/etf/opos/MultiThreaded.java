package org.unibl.etf.opos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MultiThreaded {

    private static final int NUM_THREADS = 16;

    public static Map<String, Integer> run(String filePath) throws IOException, InterruptedException, ExecutionException {
        try(ExecutorService executor = Executors.newFixedThreadPool(NUM_THREADS)) {
            List<Future<Map<String, Integer>>> futures = new ArrayList<>();

            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                List<String> chunk = new ArrayList<>();
                while ((line = reader.readLine()) != null) {
                    chunk.add(line);
                    if (chunk.size() == 1000) {
                        Future<Map<String, Integer>> wordCountFuture = executor.submit(new WordCountTask(new ArrayList<>(chunk)));
                        futures.add(wordCountFuture);
                        chunk.clear();
                    }
                }
                if (!chunk.isEmpty()) {
                    futures.add(executor.submit(new WordCountTask(chunk)));
                }
            }

            Map<String, Integer> wordCounts = new HashMap<>();
            for (Future<Map<String, Integer>> future : futures) {
                Map<String, Integer> result = future.get();
                result.forEach((word, count) -> wordCounts.merge(word, count, Integer::sum));
            }

            return wordCounts;
        }
    }
}
