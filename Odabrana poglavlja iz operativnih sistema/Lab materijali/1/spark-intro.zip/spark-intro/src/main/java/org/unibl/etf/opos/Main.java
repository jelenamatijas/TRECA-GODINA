package org.unibl.etf.opos;


import java.util.Map;

public class Main {
    public static void main(String[] args) throws Exception  {

        String filePath = "/home/bojanb/Downloads/large/bible_1000.txt";

        long startTime = System.currentTimeMillis();

        Map<String, Integer> wordCounts = MultiThreaded.run(filePath);

        long endTime = System.currentTimeMillis();

        System.out.println(endTime - startTime);

        // wordCounts.forEach((word, count) -> System.out.println(word + ": " + count));

    }
}