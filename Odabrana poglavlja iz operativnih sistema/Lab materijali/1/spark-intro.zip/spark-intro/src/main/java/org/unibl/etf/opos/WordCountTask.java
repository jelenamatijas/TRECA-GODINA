package org.unibl.etf.opos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

class WordCountTask implements Callable<Map<String, Integer>> {
    private final List<String> lines;

    WordCountTask(List<String> lines) {
        this.lines = lines;
    }

    @Override
    public Map<String, Integer> call() {
        Map<String, Integer> wordCounts = new HashMap<>();
        for (String line : lines) {
            String[] words = line.toLowerCase().replaceAll("[^a-zA-Z ]", "").split("\\s+");
            for (String word : words) {
                wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
            }
        }
        return wordCounts;
    }
}
