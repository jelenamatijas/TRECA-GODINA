from pprint import pprint
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

spark = SparkSession.builder.appName("UnionExample").getOrCreate()

order_schema = StructType(
    [
        StructField("order_id", StringType(), True),
        StructField("customer_id", IntegerType(), True),
        StructField("product_id", IntegerType(), True),
        StructField("quantity", IntegerType(), True),
    ]
)

legacy_orders = spark.createDataFrame(
    [("LEGACY_1", 5, 101, 2), ("LEGACY_2", 8, 103, 1), ("LEGACY_3", 5, 102, 3)],
    schema=order_schema,
)

new_orders = spark.createDataFrame(
    [("NEW_1", 12, 101, 1), ("NEW_2", 5, 104, 2)], schema=order_schema
)

all_orders = legacy_orders.union(new_orders)

print("Combined Orders:")
all_orders.show()

pprint(all_orders.collect())

spark.stop()
