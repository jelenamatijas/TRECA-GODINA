from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
)
from pprint import pprint

spark = SparkSession.builder.appName("JoinExample").getOrCreate()  # type: ignore

orders_schema = StructType(
    [
        StructField("product_id", IntegerType(), True),
        StructField("order_id", StringType(), True),
        StructField("quantity", IntegerType(), True),
    ]
)

products_schema = StructType(
    [
        StructField("product_id", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("price", DoubleType(), True),
    ]
)

orders_data = spark.createDataFrame(
    [
        (101, "LEGACY_1", 2),
        (103, "LEGACY_2", 1),
        (102, "LEGACY_3", 3),
        (101, "NEW_1", 1),
    ],
    schema=orders_schema,
)

products_data = spark.createDataFrame(
    [
        (101, "Laptop", 999.99),
        (102, "Mouse", 24.99),
        (103, "Keyboard", 49.99),
        (104, "Monitor", 299.99),
    ],
    schema=products_schema,
)

inner_join = orders_data.join(products_data, "product_id")
left_join = orders_data.join(products_data, "product_id", "left")
right_join = orders_data.join(products_data, "product_id", "right")

print("Inner Join Results:")
inner_join.show()

print("\nLeft Join Results:")
left_join.show()

print("\nRight Join Results:")
right_join.show()

print("\nInner Join Results (collected):")
pprint(inner_join.collect())

spark.stop()
