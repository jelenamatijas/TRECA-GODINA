from pprint import pprint
from pyspark import SparkContext

sc = SparkContext()

legacy_orders = sc.parallelize(
    [("LEGACY_1", 5, 101, 2), ("LEGACY_2", 8, 103, 1), ("LEGACY_3", 5, 102, 3)]
)

new_orders = sc.parallelize([("NEW_1", 12, 101, 1), ("NEW_2", 5, 104, 2)])

all_orders = legacy_orders.union(new_orders)

pprint(all_orders.collect())

sc.stop()
