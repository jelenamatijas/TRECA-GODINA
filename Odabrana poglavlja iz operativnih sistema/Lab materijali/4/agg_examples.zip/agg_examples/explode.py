from pyspark.sql import SparkSession
from pyspark.sql.functions import explode

spark = (SparkSession.builder
    .remote("sc://spark-connect:15002")
    .appName("wordcount-uploaded")
    .create()
)

data_before = [
    (101, "Marketing", ["Laptop", "Monitor"]),
    (102, "HR", ["Keyboard"]),
    (103, "Engineering", ["Server", "GPU", "Docking Station"]),
]

columns_before = ["dept_id", "department_name", "requested_supplies"]

df_before = spark.createDataFrame(data_before, columns_before)

df_before.show(truncate=False)
df_before.printSchema()


df_after = df_before.select(
    "dept_id", "department_name", explode("requested_supplies").alias("supply_item")
)

df_after.show(truncate=False)
df_after.printSchema()