from pyspark import SparkContext
from pprint import pprint

# JOIN combines data from different sources based on a common key

# Orders Data (after preparation for join):
# Key: product_id
# ----------------------------------------
# | product_id | (order_id, quantity)     |
# ----------------------------------------
# | 101        | (LEGACY_1, 2)           |
# | 103        | (LEGACY_2, 1)           |
# | 102        | (LEGACY_3, 3)           |
# | 101        | (NEW_1, 1)              |
# ----------------------------------------

# Products Data:
# -------------------------------------------
# | product_id | (name, price)             |
# -------------------------------------------
# | 101        | (Laptop, 999.99)          |
# | 102        | (Mouse, 24.99)            |
# | 103        | (Keyboard, 49.99)         |
# | 104        | (Monitor, 299.99)         |
# -------------------------------------------

# 1. INNER JOIN (orders.join(products)):
# ------------------------------------------------------------
# | product_id | ((order_id, quantity), (name, price))        |
# ------------------------------------------------------------
# | 101        | ((LEGACY_1, 2), (Laptop, 999.99))           |
# | 101        | ((NEW_1, 1), (Laptop, 999.99))              |
# | 102        | ((LEGACY_3, 3), (Mouse, 24.99))             |
# | 103        | ((LEGACY_2, 1), (Keyboard, 49.99))          |
# ------------------------------------------------------------

# 2. LEFT OUTER JOIN (orders.leftOuterJoin(products)):
# ------------------------------------------------------------
# | product_id | ((order_id, quantity), Option[(name, price)])|
# ------------------------------------------------------------
# | 101        | ((LEGACY_1, 2), Some((Laptop, 999.99)))     |
# | 101        | ((NEW_1, 1), Some((Laptop, 999.99)))        |
# | 102        | ((LEGACY_3, 3), Some((Mouse, 24.99)))       |
# | 103        | ((LEGACY_2, 1), Some((Keyboard, 49.99)))    |
# ------------------------------------------------------------

sc = SparkContext()

orders_data = sc.parallelize(
    [
        (101, ("LEGACY_1", 2)),
        (103, ("LEGACY_2", 1)),
        (102, ("LEGACY_3", 3)),
        (101, ("NEW_1", 1)),
    ]
)

products_data = sc.parallelize(
    [
        (101, ("Laptop", 999.99)),
        (102, ("Mouse", 24.99)),
        (103, ("Keyboard", 49.99)),
        (104, ("Monitor", 299.99)),
    ]
)

# Different types of joins
inner_join = orders_data.join(products_data)
left_join = orders_data.leftOuterJoin(products_data)
right_join = orders_data.rightOuterJoin(products_data)

pprint(inner_join.collect())


sc.stop()
