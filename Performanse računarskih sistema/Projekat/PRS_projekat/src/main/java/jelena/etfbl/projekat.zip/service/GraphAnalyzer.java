package jelena.etfbl.service;

import jelena.etfbl.database.Table;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import java.util.*;

public class GraphAnalyzer {
    private static final Logger log = LoggerFactory.getLogger(GraphAnalyzer.class);
    private Map<String, Table> tables;

    public GraphAnalyzer(Map<String, Table> tables){
        this.tables = tables;
    }

    public List<List<String>> findSameLevels() {
        Map<String, Integer> inDegree = new HashMap<>();
        Map<String, List<String>> adjList = new HashMap<>();

        // 1. Иницијализација
        for (String table : tables.keySet()) {
            inDegree.put(table, 0);
            adjList.put(table, new ArrayList<>());
        }

        // 2. Прављење графа (Ко од кога зависи)
        for (Table t : tables.values()) {
            String trenutnaTabela = t.getTableName();
            for (String zavisnost : t.getDependencies()) {
                if (tables.containsKey(zavisnost) && !zavisnost.equals(trenutnaTabela)) {
                    // Смер гране: zavisnost -> trenutnaTabela
                    adjList.get(zavisnost).add(trenutnaTabela);
                    inDegree.put(trenutnaTabela, inDegree.get(trenutnaTabela) + 1);
                }
            }
        }

        List<List<String>> levels = new ArrayList<>();
        Queue<String> red = new LinkedList<>();

        // 3. Додајемо све табеле које немају зависности (Level 0)
        for (Map.Entry<String, Integer> entry : inDegree.entrySet()) {
            if (entry.getValue() == 0) {
                red.offer(entry.getKey());
            }
        }

        int obradjeno = 0;

        // 4. Кахнов алгоритам по нивоима
        while (!red.isEmpty()) {
            int velicinaNivoa = red.size();
            List<String> trenutniNivo = new ArrayList<>();

            for (int i = 0; i < velicinaNivoa; i++) {
                String tabela = red.poll();
                trenutniNivo.add(tabela);
                obradjeno++;

                // Смањујемо in-degree свим табелама које зависе од ове
                for (String komsija : adjList.get(tabela)) {
                    inDegree.put(komsija, inDegree.get(komsija) - 1);
                    // Тек кад све њене зависности буду испуњене (0), иде у ред
                    if (inDegree.get(komsija) == 0) {
                        red.offer(komsija);
                    }
                }
            }
            levels.add(trenutniNivo);
        }

        // 5. Детекција циклуса (Circular Dependency) - заштита од пуцања
        if (obradjeno != tables.size()) {
            log.warn("Детектован циклус у бази! Неке табеле неће бити правилно сортиране.");
            List<String> preostale = new ArrayList<>();
            for (Map.Entry<String, Integer> entry : inDegree.entrySet()) {
                if (entry.getValue() > 0) {
                    preostale.add(entry.getKey());
                }
            }
            if (!preostale.isEmpty()) {
                levels.add(preostale);
            }
        }

        return levels;
    }

    public String renderGraph() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== TABLE DEPENDENCY GRAPH ===\n\n");
        List<List<String>> levels = findSameLevels();
        for (int i = 0; i < levels.size(); i++) {
            sb.append(String.format("Level %d (parallel): %s\n", i, levels.get(i)));
        }
        return sb.toString();
    }
}